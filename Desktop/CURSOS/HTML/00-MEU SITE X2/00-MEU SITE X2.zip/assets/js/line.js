
//Lines
var c = document.getElementById("l1");
var ctx = c.getContext("2d");
ctx.moveTo(0, 150);
ctx.lineTo(300, 0);
ctx.lineWidth = 5;
ctx.strokeStyle = '#666';
ctx.stroke();


var c = document.getElementById("l2");
var ctx = c.getContext("2d");
ctx.moveTo(0, 150);
ctx.lineTo(300, 0);
ctx.lineWidth = 5;
ctx.strokeStyle = '#666';
ctx.stroke();